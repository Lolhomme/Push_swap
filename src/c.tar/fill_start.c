/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   fill_start.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jponcele <jponcele@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/12/26 13:39:23 by jponcele          #+#    #+#             */
/*   Updated: 2013/12/27 17:52:00 by jponcele         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <push_swap.h>

void			fill_start(t_ps *ps, int ac, char **av)
{
	int			n;

	while (ac > 0)
	{
		n = ft_atoi(av[ac - 1]);
		ft_dlstaddfront(ft_dlstnew(n), ps->a_adlst, ps->a_zdlst);
		ps->a_size++;
		ac--;
	}
}
