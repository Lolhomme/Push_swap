/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jponcele <jponcele@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/12/26 10:49:12 by jponcele          #+#    #+#             */
/*   Updated: 2013/12/27 17:47:26 by jponcele         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <push_swap.h>

int			main(int ac, char **av)
{
	t_ps	*ps;

	ac--;
	av++;
	if (ac < 2)
		exit(0);
	ps = init_ps(ps);
	fill_start(ps, ac, av);
	ps_tri(ps);
	free_ps(ps);
	ft_putchar('\n');
	return (0);
}
