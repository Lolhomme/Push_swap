/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ps_pass.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jponcele <jponcele@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/12/27 10:48:55 by jponcele          #+#    #+#             */
/*   Updated: 2013/12/27 17:47:30 by jponcele         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <push_swap.h>

void			ps_passa(t_ps *ps)
{
	t_dlst		*src;

	ft_putstr("pb ");
	src = *(ps->a_adlst);
	if (!src->next)
		return ;
	*(ps->a_adlst) = src->next;
	if (src->next)
		src->next->prev = NULL;
	ft_dlstaddfront(src, ps->b_adlst, ps->b_zdlst);
	ps->a_size--;
}

void			ps_passb(t_ps *ps)
{
	t_dlst		*src;

	ft_putstr("pa");
	src = *(ps->b_adlst);
	if (!src->next)
		return ;
	*(ps->b_adlst) = src->next;
	if (src->next)
		src->next->prev = NULL;
	ft_dlstaddfront(src, ps->a_adlst, ps->a_zdlst);
}
